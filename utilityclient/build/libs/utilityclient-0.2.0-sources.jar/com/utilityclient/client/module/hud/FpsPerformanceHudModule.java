package com.utilityclient.client.module.hud;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.util.RenderUtil;
import com.utilityclient.client.util.TpsTracker;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class FpsPerformanceHudModule extends HudModule {
    private final BooleanSetting showTps = addSetting(new BooleanSetting("showTPS", "Show estimated TPS", true));
    private final BooleanSetting showPing = addSetting(new BooleanSetting("showPing", "Show multiplayer ping", true));

    public FpsPerformanceHudModule(class_304 keybind) {
        super("FPS & Performance HUD", "FPS, frametime, TPS, and ping.", Category.HUD, keybind, 12, 300);
        width = 170;
        height = 54;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible()) {
            return;
        }
        int fps = class_310.method_1551().method_47599();
        double frameMs = fps > 0 ? 1000.0D / fps : 0.0D;
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        RenderUtil.text(graphics, "FPS: " + fps + " | " + String.format("%.2f ms", frameMs), getX() + 6, getY() + 6, 0xFFFFFFFF);
        int y = getY() + 18;
        if (showTps.get()) {
            double tps = TpsTracker.getTps();
            int tpsColor = tps >= 19.5 ? 0xFF10B981 : tps >= 15.0 ? 0xFFFBBF24 : 0xFFEF4444;
            RenderUtil.text(graphics, String.format("TPS est: %.1f", tps), getX() + 6, y, tpsColor);
            y += 12;
        }
        if (showPing.get() && client.method_1562() != null && client.field_1724 != null) {
            int ping = client.method_1562().method_2871(client.field_1724.method_5667()) != null
                ? client.method_1562().method_2871(client.field_1724.method_5667()).method_2959()
                : 0;
            RenderUtil.text(graphics, "Ping: " + ping + " ms", getX() + 6, y, 0xFF93C5FD);
        }
    }
}
