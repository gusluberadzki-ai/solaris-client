package com.utilityclient.client.module.hud;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.ColorSetting;
import com.utilityclient.client.util.RenderUtil;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class KeystrokesHudModule extends HudModule {
    private final BooleanSetting showCps = addSetting(new BooleanSetting("showCPS", "Show click counters", true));
    private final ColorSetting activeColor = addSetting(new ColorSetting("activeColor", "Active key color", 16, 185, 129, 255));
    private final ColorSetting inactiveColor = addSetting(new ColorSetting("inactiveColor", "Inactive key color", 55, 65, 81, 255));

    private int leftClicks;
    private int rightClicks;
    private boolean lastAttackDown;
    private boolean lastUseDown;

    public KeystrokesHudModule(class_304 keybind) {
        super("Keystrokes HUD", "WASD and mouse-button overlay.", Category.HUD, keybind, 210, 250);
        width = 108;
        height = 80;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onTick(class_310 client) {
        boolean attackDown = client.field_1690.field_1886.method_1434();
        boolean useDown = client.field_1690.field_1904.method_1434();
        if (attackDown && !lastAttackDown) {
            leftClicks++;
        }
        if (useDown && !lastUseDown) {
            rightClicks++;
        }
        lastAttackDown = attackDown;
        lastUseDown = useDown;
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible()) {
            return;
        }
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        drawKey(graphics, "W", getX() + 36, getY() + 6, client.field_1690.field_1894.method_1434());
        drawKey(graphics, "A", getX() + 8, getY() + 28, client.field_1690.field_1913.method_1434());
        drawKey(graphics, "S", getX() + 36, getY() + 28, client.field_1690.field_1881.method_1434());
        drawKey(graphics, "D", getX() + 64, getY() + 28, client.field_1690.field_1849.method_1434());
        drawKey(graphics, "SP", getX() + 8, getY() + 50, client.field_1690.field_1903.method_1434());
        drawKey(graphics, "SH", getX() + 64, getY() + 50, client.field_1690.field_1832.method_1434());
        if (showCps.get()) {
            RenderUtil.text(graphics, "LMB " + leftClicks + " | RMB " + rightClicks, getX() + 6, getY() + height - 12, 0xFFFFFFFF);
        }
    }

    private void drawKey(class_332 graphics, String label, int x, int y, boolean active) {
        int[] color = active ? activeColor.get() : inactiveColor.get();
        int argb = (color[3] << 24) | (color[0] << 16) | (color[1] << 8) | color[2];
        graphics.method_25294(x, y, x + 24, y + 16, argb);
        RenderUtil.text(graphics, label, x + 7, y + 4, 0xFFFFFFFF);
    }
}
