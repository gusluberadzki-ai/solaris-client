package com.utilityclient.client.module.misc;

import com.utilityclient.client.module.Category;
import com.utilityclient.client.module.Module;
import com.utilityclient.client.setting.BooleanSetting;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ToggleSprintSneakModule extends Module {
    private final BooleanSetting toggleSprint = addSetting(new BooleanSetting("toggleSprint", "Enable sprint toggle", true));
    private final BooleanSetting toggleSneak = addSetting(new BooleanSetting("toggleSneak", "Enable sneak toggle", true));
    private final BooleanSetting showIndicator = addSetting(new BooleanSetting("showIndicator", "Show HUD indicator", true));
    private boolean sprintState;
    private boolean sneakState;
    private boolean lastSprintKey;
    private boolean lastSneakKey;

    public ToggleSprintSneakModule(class_304 keybind) {
        super("ToggleSprint / ToggleSneak", "One-press sprint and sneak toggles.", Category.MOVEMENT, keybind);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        sprintState = false;
        sneakState = false;
    }

    @Override
    public void onTick(class_310 client) {
        boolean sprintKey = client.field_1690.field_1867.method_1434();
        boolean sneakKey = client.field_1690.field_1832.method_1434();
        if (toggleSprint.get() && sprintKey && !lastSprintKey) {
            sprintState = !sprintState;
        }
        if (toggleSneak.get() && sneakKey && !lastSneakKey) {
            sneakState = !sneakState;
        }
        lastSprintKey = sprintKey;
        lastSneakKey = sneakKey;
        if (client.field_1724 != null) {
            client.field_1724.method_5728(sprintState);
            client.field_1690.field_1832.method_23481(sneakState);
        }
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        if (!showIndicator.get()) {
            return;
        }
        int y = class_310.method_1551().method_22683().method_4502() - 30;
        graphics.method_25303(class_310.method_1551().field_1772, "Sprint: " + (sprintState ? "ON" : "OFF") + " Sneak: " + (sneakState ? "ON" : "OFF"), 8, y, 0xFFFFFFFF);
    }
}
