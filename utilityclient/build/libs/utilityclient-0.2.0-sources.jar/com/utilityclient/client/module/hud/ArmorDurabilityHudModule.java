package com.utilityclient.client.module.hud;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.IntegerSetting;
import com.utilityclient.client.util.RenderUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ArmorDurabilityHudModule extends HudModule {
    private final BooleanSetting showNumbers = addSetting(new BooleanSetting("showNumbers", "Show durability numbers", true));
    private final IntegerSetting warningThreshold = addSetting(new IntegerSetting("warningThreshold", "Flash threshold percent", 20, 0, 100));

    public ArmorDurabilityHudModule(class_304 keybind) {
        super("Armor Durability HUD", "Player, spear, and mount armor durability tracking.", Category.HUD, keybind, 210, 120);
        width = 190;
        height = 90;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible() || client.field_1724 == null) {
            return;
        }
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        int y = getY() + 6;

        List<class_1799> stacks = new ArrayList<>();
        class_1661 inventory = client.field_1724.method_31548();
        stacks.add(client.field_1724.method_6118(class_1304.field_6169));
        stacks.add(client.field_1724.method_6118(class_1304.field_6174));
        stacks.add(client.field_1724.method_6118(class_1304.field_6172));
        stacks.add(client.field_1724.method_6118(class_1304.field_6166));
        stacks.add(inventory.method_7391());
        stacks.add(client.field_1724.method_6079());
        if (client.field_1724.method_5854() instanceof net.minecraft.class_1309 mount) {
            class_1799 armor = mount.method_6118(class_1304.field_48824);
            if (!armor.method_7960()) {
                stacks.add(armor);
            }
        }

        for (class_1799 stack : stacks.stream().limit(7).toList()) {
            if (stack.method_7960() || !stack.method_7963()) {
                continue;
            }
            int max = stack.method_7936();
            int remaining = max - stack.method_7919();
            double percent = remaining / (double) max;
            int color = RenderUtil.durabilityColor(percent);
            String text = stack.method_7964().getString();
            if (showNumbers.get()) {
                text += " " + remaining + "/" + max;
            }
            if (stack.method_7964().getString().toLowerCase().contains("spear")) {
                text += client.field_1724.method_6115() ? " [Charge]" : " [Jab]";
            }
            RenderUtil.text(graphics, text, getX() + 6, y, color);
            y += 12;
        }
        height = Math.max(30, y - getY() + 6);
    }
}
