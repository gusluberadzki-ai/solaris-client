package com.utilityclient.client.module.mount;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.util.RenderUtil;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7689;

public final class MountHudModule extends HudModule {
    private final BooleanSetting showMountHealth = addSetting(new BooleanSetting("showMountHealth", "Show mount health", true));
    private final BooleanSetting showMountArmor = addSetting(new BooleanSetting("showMountArmor", "Show mount armor", true));
    private final BooleanSetting showJumpMeter = addSetting(new BooleanSetting("showJumpMeter", "Show horse jump charge", true));
    private final BooleanSetting showSpearCharge = addSetting(new BooleanSetting("showSpearCharge", "Show mounted spear charge", true));

    public MountHudModule(class_304 keybind) {
        super("Mount HUD", "Dedicated mount HUD for horses, camels, and 1.21.11 nautilus mounts.", Category.MOUNT, keybind, 410, 12);
        width = 220;
        height = 74;
        setEnabledSilently(true);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible() || client.field_1724 == null || !(client.field_1724.method_5854() instanceof class_1309 mount)) {
            return;
        }

        RenderUtil.panel(graphics, getX(), getY(), width, height);
        int y = getY() + 6;
        RenderUtil.text(graphics, "Mount: " + mountLabel(mount), getX() + 6, y, 0xFFFFFFFF);
        y += 12;

        if (showMountHealth.get()) {
            RenderUtil.text(graphics, String.format("Health: %.1f / %.1f", mount.method_6032(), mount.method_6063()), getX() + 6, y, 0xFF10B981);
            y += 12;
        }

        if (showMountArmor.get()) {
            class_1799 armor = mount.method_6118(class_1304.field_48824);
            String armorText = armor.method_7960() ? "None" : armor.method_7964().getString();
            if (!armor.method_7960() && armor.method_7963()) {
                armorText += " " + (armor.method_7936() - armor.method_7919()) + "/" + armor.method_7936();
            }
            RenderUtil.text(graphics, "Armor: " + armorText, getX() + 6, y, 0xFF93C5FD);
            y += 12;
        }

        if (showJumpMeter.get() && mount instanceof class_1496) {
            RenderUtil.text(graphics, "Jump: " + String.format("%.0f%%", client.field_1724.method_3151() * 100.0F), getX() + 6, y, 0xFFFBBF24);
            y += 12;
        }

        if (showSpearCharge.get()) {
            class_1799 mainHand = client.field_1724.method_6047();
            if (!mainHand.method_7960() && mainHand.method_7964().getString().toLowerCase().contains("spear")) {
                int used = client.field_1724.method_6115() ? mainHand.method_7935(client.field_1724) - client.field_1724.method_6014() : 0;
                RenderUtil.text(graphics, "Spear Charge: " + used + "t", getX() + 6, y, 0xFF8B5CF6);
            }
        }
    }

    private String mountLabel(class_1309 mount) {
        String name = mount.method_5864().toString().toLowerCase();
        if (name.contains("zombie_nautilus")) return "Zombie Nautilus";
        if (name.contains("nautilus")) return "Nautilus";
        if (name.contains("camel_husk")) return "Camel Husk";
        if (name.contains("camel")) return "Camel";
        if (name.contains("zombie_horse")) return "Zombie Horse";
        if (mount instanceof class_7689) return "Camel";
        return "Horse";
    }
}
