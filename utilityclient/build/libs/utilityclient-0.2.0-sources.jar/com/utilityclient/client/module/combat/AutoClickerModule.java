package com.utilityclient.client.module.combat;

import com.utilityclient.client.module.Category;
import com.utilityclient.client.module.Module;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.IntegerSetting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public final class AutoClickerModule extends Module {
    private final IntegerSetting minCps = addSetting(new IntegerSetting("minCPS", "Minimum click rate", 8, 1, 25));
    private final IntegerSetting maxCps = addSetting(new IntegerSetting("maxCPS", "Maximum click rate", 12, 1, 25));
    private final BooleanSetting leftClick = addSetting(new BooleanSetting("leftClick", "Autoclick attack", true));
    private final BooleanSetting rightClick = addSetting(new BooleanSetting("rightClick", "Autoclick use", false));
    private final BooleanSetting respectSpearCharge = addSetting(new BooleanSetting("respectSpearCharge", "Do not interrupt spear charge attacks", true));

    private long nextLeftClick;
    private long nextRightClick;

    public AutoClickerModule(class_304 keybind) {
        super("AutoClicker", "Held-button Gaussian autoclicker with spear awareness.", Category.COMBAT, keybind);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1755 != null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (leftClick.get() && client.field_1690.field_1886.method_1434() && now >= nextLeftClick && !shouldRespectSpearCharge(client)) {
            if (client.field_1761 != null && client.field_1724 != null && client.field_1765 instanceof class_3966 entityHitResult) {
                client.field_1761.method_2918(client.field_1724, entityHitResult.method_17782());
            }
            if (client.field_1724 != null) {
                client.field_1724.method_6104(class_1268.field_5808);
            }
            nextLeftClick = now + delayMillis();
        }
        if (rightClick.get() && client.field_1690.field_1904.method_1434() && now >= nextRightClick && !shouldRespectSpearCharge(client)) {
            if (client.field_1761 != null && client.field_1724 != null) {
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            }
            nextRightClick = now + delayMillis();
        }
    }

    private boolean shouldRespectSpearCharge(class_310 client) {
        if (!respectSpearCharge.get() || client.field_1724 == null) {
            return false;
        }
        class_1799 stack = client.field_1724.method_6047();
        String id = stack.method_7909().toString().toLowerCase();
        return id.contains("spear") && client.field_1724.method_6115();
    }

    private long delayMillis() {
        int min = Math.min(minCps.get(), maxCps.get());
        int max = Math.max(minCps.get(), maxCps.get());
        double sample = ThreadLocalRandom.current().nextGaussian((min + max) / 2.0D, Math.max(0.35D, (max - min) / 4.0D));
        double cps = Math.max(min, Math.min(max, sample));
        return (long) (1000.0D / cps);
    }
}
