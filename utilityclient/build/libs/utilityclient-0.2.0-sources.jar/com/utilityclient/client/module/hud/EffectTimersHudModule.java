package com.utilityclient.client.module.hud;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.EnumSetting;
import com.utilityclient.client.setting.IntegerSetting;
import com.utilityclient.client.util.RenderUtil;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class EffectTimersHudModule extends HudModule {
    public enum SortOrder {
        TIME_REMAINING,
        NAME,
        AMPLIFIER
    }

    private final BooleanSetting showIcon = addSetting(new BooleanSetting("showIcon", "Show effect icon spacing", true));
    private final BooleanSetting showAmplifier = addSetting(new BooleanSetting("showAmplifier", "Show amplifier", true));
    private final IntegerSetting maxShown = addSetting(new IntegerSetting("maxShown", "Maximum effects shown", 6, 1, 16));
    private final EnumSetting<SortOrder> sortOrder = addSetting(new EnumSetting<>("sortOrder", "Sorting mode", SortOrder.TIME_REMAINING, SortOrder.class));

    public EffectTimersHudModule(class_304 keybind) {
        super("Effect Timers HUD", "Potion-effect HUD with timers.", Category.HUD, keybind, 210, 12);
        width = 180;
        height = 80;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible() || client.field_1724 == null) {
            return;
        }
        List<class_1293> effects = client.field_1724.method_6026().stream().sorted(comparator()).limit(maxShown.get()).toList();
        height = Math.max(26, 14 + effects.size() * 12);
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        int y = getY() + 6;
        for (class_1293 effect : effects) {
            String label = effect.method_5579().comp_349().method_5560().getString();
            if (showAmplifier.get()) {
                label += " " + (effect.method_5578() + 1);
            }
            label += " " + format(effect.method_5584());
            RenderUtil.text(graphics, (showIcon.get() ? "* " : "") + label, getX() + 6, y, 0xFFFFFFFF);
            y += 12;
        }
    }

    private Comparator<class_1293> comparator() {
        return switch (sortOrder.get()) {
            case NAME -> Comparator.comparing(effect -> effect.method_5579().comp_349().method_5560().getString());
            case AMPLIFIER -> Comparator.comparingInt(class_1293::method_5578).reversed();
            case TIME_REMAINING -> Comparator.comparingInt(class_1293::method_5584).reversed();
        };
    }

    private String format(int ticks) {
        int totalSeconds = ticks / 20;
        return String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
    }
}
