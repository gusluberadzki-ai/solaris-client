package com.utilityclient.client.module.hud;

import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.IntegerSetting;
import com.utilityclient.client.util.RenderUtil;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class PositionIndicatorHudModule extends HudModule {
    private final BooleanSetting showBiome = addSetting(new BooleanSetting("showBiome", "Display biome", true));
    private final BooleanSetting showDimension = addSetting(new BooleanSetting("showDimension", "Display dimension", true));
    private final BooleanSetting showNetherCoords = addSetting(new BooleanSetting("showNetherCoords", "Display converted coords", true));
    private final IntegerSetting decimalPlaces = addSetting(new IntegerSetting("decimalPlaces", "Coordinate precision", 2, 0, 4));

    public PositionIndicatorHudModule(class_304 keybind) {
        super("Position Indicator HUD", "Coordinates, direction, biome, and dimension.", Category.HUD, keybind, 12, 140);
        width = 185;
        height = 58;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible() || client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        class_2338 pos = client.field_1724.method_24515();
        String format = "%." + decimalPlaces.get() + "f";
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        RenderUtil.text(graphics,
            "XYZ: " + String.format(format, client.field_1724.method_23317())
                + ", " + String.format(format, client.field_1724.method_23318())
                + ", " + String.format(format, client.field_1724.method_23321()),
            getX() + 6, getY() + 6, 0xFFFFFFFF);
        RenderUtil.text(graphics,
            "Facing: " + client.field_1724.method_5735().method_10151()
                + " (" + String.format("%.1f", client.field_1724.method_36454()) + ")",
            getX() + 6, getY() + 18, 0xFF93C5FD);
        int lineY = getY() + 30;

        if (showBiome.get()) {
            RenderUtil.text(graphics, "Biome: " + biomeName(client, pos), getX() + 6, lineY, 0xFF10B981);
            lineY += 12;
        }
        if (showDimension.get()) {
            RenderUtil.text(graphics, "Dim: " + dimensionName(client), getX() + 6, lineY, 0xFFFFFFFF);
            lineY += 12;
        }
        if (showNetherCoords.get()) {
            double scale = class_1937.field_25180.equals(client.field_1687.method_27983()) ? 8.0D : 0.125D;
            RenderUtil.text(graphics,
                String.format("Conv: %.1f, %.1f", client.field_1724.method_23317() * scale, client.field_1724.method_23321() * scale),
                getX() + 6, lineY, 0xFFFBBF24);
            height = 66;
        } else {
            height = Math.max(42, lineY - getY());
        }
    }

    private static String biomeName(class_310 client, class_2338 pos) {
        try {
            return client.field_1687.method_23753(pos).method_40230()
                .map(k -> k.method_29177().method_12832().replace('_', ' '))
                .orElse("unknown");
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static String dimensionName(class_310 client) {
        var dim = client.field_1687.method_27983();
        if (class_1937.field_25179.equals(dim)) return "Overworld";
        if (class_1937.field_25180.equals(dim))    return "Nether";
        if (class_1937.field_25181.equals(dim))       return "End";
        // Modded dimension: parse "ResourceKey[... / namespace:path]" → "path"
        String raw = dim.toString();
        int slash = raw.lastIndexOf('/');
        if (slash >= 0 && raw.endsWith("]")) {
            return raw.substring(slash + 2, raw.length() - 1);
        }
        return raw;
    }
}
