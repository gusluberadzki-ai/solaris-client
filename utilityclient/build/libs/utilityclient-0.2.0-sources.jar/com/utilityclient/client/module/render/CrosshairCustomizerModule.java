package com.utilityclient.client.module.render;

import com.utilityclient.client.module.Category;
import com.utilityclient.client.module.Module;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.ColorSetting;
import com.utilityclient.client.setting.EnumSetting;
import com.utilityclient.client.setting.IntegerSetting;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class CrosshairCustomizerModule extends Module {
    public enum Shape {
        DEFAULT,
        CROSS,
        DOT,
        CIRCLE,
        PLUS
    }

    private final EnumSetting<Shape> shape = addSetting(new EnumSetting<>("shape", "Crosshair shape", Shape.CROSS, Shape.class));
    private final IntegerSetting size = addSetting(new IntegerSetting("size", "Crosshair size", 6, 1, 24));
    private final IntegerSetting thickness = addSetting(new IntegerSetting("thickness", "Crosshair thickness", 2, 1, 8));
    private final IntegerSetting gap = addSetting(new IntegerSetting("gap", "Center gap", 3, 0, 12));
    private final BooleanSetting dynamic = addSetting(new BooleanSetting("dynamic", "Expand while moving", true));
    private final ColorSetting color = addSetting(new ColorSetting("color", "RGBA color", 255, 255, 255, 255));

    public CrosshairCustomizerModule(class_304 keybind) {
        super("Crosshair Customizer", "Custom client crosshair overlay.", Category.RENDER, keybind);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842) {
            return;
        }
        int[] rgba = color.get();
        int argb = (rgba[3] << 24) | (rgba[0] << 16) | (rgba[1] << 8) | rgba[2];
        int cx = client.method_22683().method_4486() / 2;
        int cy = client.method_22683().method_4502() / 2;
        int extra = dynamic.get() && client.field_1724 != null && client.field_1724.method_18798().method_37268() > 0.001 ? 2 : 0;
        int actualGap = gap.get() + extra;
        if (shape.get() == Shape.DEFAULT) {
            return;
        }
        graphics.method_25294(cx - thickness.get(), cy - size.get() - actualGap, cx + thickness.get(), cy - actualGap, argb);
        graphics.method_25294(cx - thickness.get(), cy + actualGap, cx + thickness.get(), cy + size.get() + actualGap, argb);
        graphics.method_25294(cx - size.get() - actualGap, cy - thickness.get(), cx - actualGap, cy + thickness.get(), argb);
        graphics.method_25294(cx + actualGap, cy - thickness.get(), cx + size.get() + actualGap, cy + thickness.get(), argb);
        if (shape.get() == Shape.DOT || shape.get() == Shape.CIRCLE) {
            graphics.method_25294(cx - 1, cy - 1, cx + 1, cy + 1, argb);
        }
    }
}
