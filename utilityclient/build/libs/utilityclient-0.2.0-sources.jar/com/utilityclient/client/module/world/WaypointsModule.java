package com.utilityclient.client.module.world;

import com.utilityclient.client.UtilityClientClient;
import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.setting.IntegerSetting;
import com.utilityclient.client.util.RenderUtil;
import com.utilityclient.client.waypoint.Waypoint;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public final class WaypointsModule extends HudModule {
    private final IntegerSetting fadeCutoff = addSetting(new IntegerSetting("distanceFadeCutoff", "Distance fade cutoff", 300, 50, 5000));

    public WaypointsModule(class_304 keybind) {
        super("Waypoints", "Waypoint labels and in-world beacon beams.", Category.WORLD, keybind, 410, 228);
        width = 180;
        height = 44;
        setEnabledSilently(true);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (!isVisible() || client.field_1724 == null) {
            return;
        }
        RenderUtil.panel(graphics, getX(), getY(), width, height);
        int y = getY() + 6;
        for (Waypoint waypoint : UtilityClientClient.waypointManager.getWaypoints()
                .stream().filter(Waypoint::enabled).limit(3).toList()) {
            double dist = client.field_1724.method_5649(waypoint.x(), waypoint.y(), waypoint.z());
            RenderUtil.text(graphics,
                waypoint.name() + " " + String.format("%.1fm", Math.sqrt(dist)),
                getX() + 6, y, waypoint.color());
            y += 12;
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_4184 camera = context.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        int cutoffSq = fadeCutoff.get() * fadeCutoff.get();

        for (Waypoint waypoint : UtilityClientClient.waypointManager.getWaypoints()) {
            if (!waypoint.enabled()) continue;
            double distSq = client.field_1724.method_5649(waypoint.x(), waypoint.y(), waypoint.z());
            if (distSq > cutoffSq) continue;

            // Relative position from camera to waypoint column base
            double dx = waypoint.x() + 0.5 - camPos.field_1352;
            double dy = waypoint.y()       - camPos.field_1351;
            double dz = waypoint.z() + 0.5 - camPos.field_1350;

            float alpha = Math.max(0.15f, 1.0f - (float)(distSq / cutoffSq));
            int color = waypoint.color();
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8)  & 0xFF) / 255f;
            float b = (color         & 0xFF) / 255f;

            class_4587 poseStack = context.matrices();
            poseStack.method_22903();
            poseStack.method_22904(dx, dy, dz);

            Matrix4f matrix = poseStack.method_23760().method_23761();

            // Draw a vertical line from waypoint Y to Y+255 using the lines render type.
            class_4588 lines = context.consumers().method_73477(class_12249.field_64042);
            lines.method_22918(matrix, 0f, 0f,   0f).method_22915(r, g, b, alpha).method_22914(0, 1, 0);
            lines.method_22918(matrix, 0f, 255f, 0f).method_22915(r, g, b, alpha).method_22914(0, 1, 0);

            poseStack.method_22909();
        }
    }
}
