package com.utilityclient.client.gui;

import com.utilityclient.client.UtilityClientClient;
import com.utilityclient.client.waypoint.Waypoint;
import net.minecraft.class_11909;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class WorldMapScreen extends class_437 {
    private double zoom = 1.0D;
    private double offsetX;
    private double offsetZ;

    public WorldMapScreen() {
        super(class_2561.method_43470("World Map"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, field_22789, field_22790, 0xC0101010);
        graphics.method_25294(30, 30, field_22789 - 30, field_22790 - 30, 0xCC111827);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 40, 0xFFFFFFFF);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            class_2338 pos = client.field_1724.method_24515();
            graphics.method_25303(field_22793, "Center: " + pos.method_10263() + ", " + pos.method_10260(), 40, 60, 0xFF93C5FD);
            graphics.method_25303(field_22793, "Zoom: " + String.format("%.2f", zoom), 40, 74, 0xFF93C5FD);
        }

        int markerY = 100;
        for (Waypoint waypoint : UtilityClientClient.waypointManager.getWaypoints()) {
            graphics.method_25303(field_22793, "- " + waypoint.name() + " [" + waypoint.x() + ", " + waypoint.z() + "]", 40, markerY, waypoint.color());
            markerY += 12;
            if (markerY > field_22790 - 50) {
                break;
            }
        }

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        zoom = Math.max(0.25D, Math.min(6.0D, zoom + scrollY * 0.1D));
        return true;
    }

    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        offsetX += dragX;
        offsetZ += dragY;
        return true;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && event.method_74245() == 1) {
            class_2338 pos = client.field_1724.method_24515();
            UtilityClientClient.waypointManager.add(new Waypoint(
                "Waypoint " + (UtilityClientClient.waypointManager.getWaypoints().size() + 1),
                pos.method_10263(),
                pos.method_10264(),
                pos.method_10260(),
                0xFF10B981,
                client.field_1724.method_73183().method_27983().method_29177().toString(),
                true
            ));
            UtilityClientClient.configManager.saveAll();
            return true;
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
