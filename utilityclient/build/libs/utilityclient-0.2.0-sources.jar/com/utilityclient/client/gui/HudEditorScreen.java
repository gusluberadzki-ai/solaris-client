package com.utilityclient.client.gui;

import com.utilityclient.client.UtilityClientClient;
import com.utilityclient.client.hud.HudModule;
import com.utilityclient.client.util.RenderUtil;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class HudEditorScreen extends class_437 {
    private HudModule dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    public HudEditorScreen() {
        super(class_2561.method_43470("HUD Editor"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, field_22789, field_22790, 0x80000000);
        List<HudModule> modules = UtilityClientClient.hudManager.getHudModules(UtilityClientClient.moduleManager.getModules());
        for (HudModule module : modules) {
            RenderUtil.panel(graphics, module.getX(), module.getY(), module.getWidth(), module.getHeight());
            RenderUtil.outlinedBox(graphics, module.getX(), module.getY(), module.getWidth(), module.getHeight(), 0xFF3B82F6);
            RenderUtil.text(graphics, module.getName(), module.getX() + 6, module.getY() + 6, 0xFFFFFFFF);
        }
        RenderUtil.centered(graphics, class_2561.method_43470("Drag HUD widgets. Positions save on close."), field_22789 / 2, 12, 0xFFFFFFFF);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        for (HudModule module : UtilityClientClient.hudManager.getHudModules(UtilityClientClient.moduleManager.getModules())) {
            if (inside(module, event.comp_4798(), event.comp_4799())) {
                dragging = module;
                dragOffsetX = (int) event.comp_4798() - module.getX();
                dragOffsetY = (int) event.comp_4799() - module.getY();
                return true;
            }
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (dragging != null) {
            dragging.setPosition((int) event.comp_4798() - dragOffsetX, (int) event.comp_4799() - dragOffsetY);
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        dragging = null;
        UtilityClientClient.configManager.saveAll();
        return super.method_25406(event);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private boolean inside(HudModule module, double mouseX, double mouseY) {
        return mouseX >= module.getX()
            && mouseX <= module.getX() + module.getWidth()
            && mouseY >= module.getY()
            && mouseY <= module.getY() + module.getHeight();
    }
}
