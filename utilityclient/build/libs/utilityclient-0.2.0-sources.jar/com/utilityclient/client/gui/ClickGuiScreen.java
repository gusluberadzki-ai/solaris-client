package com.utilityclient.client.gui;

import com.utilityclient.client.UtilityClientClient;
import com.utilityclient.client.module.Category;
import com.utilityclient.client.module.Module;
import com.utilityclient.client.setting.BooleanSetting;
import com.utilityclient.client.setting.ColorSetting;
import com.utilityclient.client.setting.DoubleSetting;
import com.utilityclient.client.setting.EnumSetting;
import com.utilityclient.client.setting.IntegerSetting;
import com.utilityclient.client.setting.Setting;
import com.utilityclient.client.setting.StringSetting;
import com.utilityclient.client.util.RenderUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class ClickGuiScreen extends class_437 {
    private enum ViewTab {
        MODULES,
        SETTINGS
    }

    private Category selectedCategory = Category.HUD;
    private Module selectedModule;
    private ViewTab activeTab = ViewTab.MODULES;

    public ClickGuiScreen() {
        super(class_2561.method_43470("Utility Client"));
    }

    @Override
    protected void method_25426() {
        if (selectedModule == null) {
            selectedModule = UtilityClientClient.moduleManager.getByCategory(selectedCategory).stream().findFirst().orElse(null);
        }
        method_41843();
    }

    @Override
    protected void method_41843() {
        method_37067();

        method_37063(class_4185.method_46430(class_2561.method_43471("screen.utilityclient.modules"), button -> {
            activeTab = ViewTab.MODULES;
            method_41843();
        }).method_46433(24, 20).method_46437(110, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("screen.utilityclient.settings"), button -> {
            activeTab = ViewTab.SETTINGS;
            method_41843();
        }).method_46433(140, 20).method_46437(110, 20).method_46431());

        int categoryX = 24;
        int y = 52;
        for (Category category : Category.values()) {
            method_37063(class_4185.method_46430(class_2561.method_43470(prefix(category == selectedCategory) + category.getDisplayName()), button -> {
                selectedCategory = category;
                if (selectedModule == null || selectedModule.getCategory() != category) {
                    selectedModule = UtilityClientClient.moduleManager.getByCategory(category).stream().findFirst().orElse(null);
                }
                method_41843();
            }).method_46433(categoryX, y).method_46437(140, 20).method_46431());
            y += 24;
        }

        buildModuleButtons();
        if (activeTab == ViewTab.SETTINGS) {
            buildSettingsButtons();
        }
    }

    private void buildModuleButtons() {
        int moduleX = 184;
        int y = 52;
        for (Module module : UtilityClientClient.moduleManager.getByCategory(selectedCategory)) {
            method_37063(class_4185.method_46430(class_2561.method_43470(moduleLabel(module)), button -> {
                if (activeTab == ViewTab.MODULES) {
                    module.toggle();
                }
                selectedModule = module;
                method_41843();
            }).method_46433(moduleX, y).method_46437(210, 20).method_46431());
            y += 24;
        }
    }

    private void buildSettingsButtons() {
        if (selectedModule == null) {
            return;
        }
        int settingX = 414;
        int y = 52;
        for (Setting<?> setting : selectedModule.getSettings()) {
            method_37063(class_4185.method_46430(class_2561.method_43470(settingLabel(setting)), button -> {
                mutateSetting(setting);
                UtilityClientClient.configManager.saveModule(selectedModule);
                method_41843();
            }).method_46433(settingX, y).method_46437(220, 20).method_46431());
            y += 24;
            if (y > field_22790 - 30) {
                break;
            }
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void mutateSetting(Setting<?> setting) {
        if (setting instanceof BooleanSetting booleanSetting) {
            booleanSetting.set(!booleanSetting.get());
            return;
        }
        if (setting instanceof IntegerSetting integerSetting) {
            integerSetting.set(integerSetting.get() + 1);
            return;
        }
        if (setting instanceof DoubleSetting doubleSetting) {
            doubleSetting.set(doubleSetting.get() + 0.1D);
            return;
        }
        if (setting instanceof EnumSetting enumSetting) {
            Enum value = (Enum) enumSetting.get();
            Object[] values = value.getDeclaringClass().getEnumConstants();
            int nextIndex = (value.ordinal() + 1) % values.length;
            enumSetting.set((Enum) values[nextIndex]);
            return;
        }
        if (setting instanceof ColorSetting colorSetting) {
            List<int[]> palette = new ArrayList<>(Arrays.asList(
                new int[] {16, 185, 129, 255},
                new int[] {59, 130, 246, 255},
                new int[] {251, 191, 36, 255},
                new int[] {239, 68, 68, 255},
                new int[] {255, 255, 255, 255}
            ));
            int[] current = colorSetting.get();
            int index = 0;
            for (int i = 0; i < palette.size(); i++) {
                if (Arrays.equals(current, palette.get(i))) {
                    index = i;
                    break;
                }
            }
            colorSetting.set(palette.get((index + 1) % palette.size()));
            return;
        }
        if (setting instanceof StringSetting stringSetting) {
            stringSetting.set(stringSetting.get() + " *");
        }
    }

    private String prefix(boolean selected) {
        return selected ? "> " : "";
    }

    private String moduleLabel(Module module) {
        String selected = selectedModule == module ? "* " : "";
        return selected + (module.isEnabled() ? "[ON] " : "[OFF] ") + module.getName();
    }

    private String settingLabel(Setting<?> setting) {
        return setting.getName() + ": " + formatValue(setting.get());
    }

    private String formatValue(Object value) {
        if (value instanceof int[] rgba) {
            return rgba[0] + "," + rgba[1] + "," + rgba[2] + "," + rgba[3];
        }
        return String.valueOf(value);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, field_22789, field_22790, 0xC0101010);
        RenderUtil.panel(graphics, 16, 14, field_22789 - 32, field_22790 - 28);
        RenderUtil.centered(graphics, class_2561.method_43470("Utility Client"), field_22789 / 2, 20, 0xFFFFFFFF);
        RenderUtil.text(graphics, "Categories", 24, 42, 0xFF93C5FD);
        RenderUtil.text(graphics, "Modules", 184, 42, 0xFF93C5FD);
        RenderUtil.text(graphics, "Settings", 414, 42, 0xFF93C5FD);
        if (selectedModule != null) {
            RenderUtil.text(graphics, selectedModule.getDescription(), 414, field_22790 - 24, 0xFFFFFFFF);
        }
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
