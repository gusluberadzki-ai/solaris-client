package com.utilityclient.client.gui;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;

public final class SolarisScreen extends class_437 {

    private static final int ACCENT  = 0xFFFF8C00;
    private static final int ACCENT2 = 0xFFFFBB44;
    private static final int BG_TOP  = 0xFF07070F;
    private static final int BG_BOT  = 0xFF111128;
    private static final int DIM     = 0xFF556688;

    private static final int BTN_W = 280;
    private static final int BTN_H = 22;
    private static final int BTN_GAP = 28;

    public SolarisScreen() {
        super(class_2561.method_43470("Solaris"));
    }

    @Override
    protected void method_25426() {
        int cx  = field_22789 / 2;
        int by  = field_22790 / 2 + 8;

        method_37063(class_4185.method_46430(
            class_2561.method_43470("SINGLEPLAYER"),
            btn -> field_22787.method_1507(new class_526(this))
        ).method_46433(cx - BTN_W / 2, by).method_46437(BTN_W, BTN_H).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43470("MULTIPLAYER"),
            btn -> field_22787.method_1507(new class_500(this))
        ).method_46433(cx - BTN_W / 2, by + BTN_GAP).method_46437(BTN_W, BTN_H).method_46431());

        int half = BTN_W / 2 - 2;
        method_37063(class_4185.method_46430(
            class_2561.method_43470("OPTIONS"),
            btn -> field_22787.method_1507(new class_429(this, field_22787.field_1690))
        ).method_46433(cx - BTN_W / 2, by + BTN_GAP * 2).method_46437(half, BTN_H).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43470("QUIT"),
            btn -> field_22787.method_1592()
        ).method_46433(cx + 2, by + BTN_GAP * 2).method_46437(half, BTN_H).method_46431());
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float pt) {
        // Dark space background
        g.method_25296(0, 0, field_22789, field_22790, BG_TOP, BG_BOT);

        // Subtle star-field dots
        drawStars(g);

        // Bottom accent bar
        g.method_25294(0, field_22790 - 20, field_22789, field_22790 - 19, 0x66FF8C00);
        g.method_25296(0, field_22790 - 19, field_22789, field_22790, 0x33FF8C00, 0x00000000);

        int cx    = field_22789 / 2;
        int logoY = field_22790 / 2 - 105;

        // Sun symbol
        drawSun(g, cx, logoY + 30, 26);

        // SOLARIS title — draw twice offset for a glow/depth effect
        g.method_27534(field_22793, class_2561.method_43470("SOLARIS").method_27692(class_124.field_1067), cx + 1, logoY + 67, 0x55FF6600);
        g.method_27534(field_22793, class_2561.method_43470("SOLARIS").method_27692(class_124.field_1067), cx,     logoY + 66, ACCENT);

        // Subtitle
        g.method_27534(field_22793, class_2561.method_43470("C L I E N T"), cx, logoY + 80, ACCENT2);

        // Thin divider under subtitle
        g.method_25294(cx - 50, logoY + 91, cx + 50, logoY + 92, 0x44FF8C00);

        // Bottom watermarks
        g.method_51433(field_22793, "Solaris 0.2.0  •  Minecraft 1.21.11", 5, field_22790 - 11, DIM, false);
        String copy = "Copyright Mojang Studios";
        g.method_51433(field_22793, copy, field_22789 - field_22793.method_1727(copy) - 5, field_22790 - 11, DIM, false);

        super.method_25394(g, mx, my, pt);
    }

    private void drawSun(class_332 g, int cx, int cy, int r) {
        // Core glow (outer soft ring)
        int core = r / 3;
        g.method_25294(cx - core - 2, cy - core - 2, cx + core + 2, cy + core + 2, 0x33FF8C00);
        // Core
        g.method_25294(cx - core, cy - core, cx + core, cy + core, ACCENT);
        // Bright center
        g.method_25294(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFFEE88);

        // Cardinal rays
        int gap = core + 3;
        g.method_25294(cx - 1, cy - r,   cx + 1, cy - gap, ACCENT2);
        g.method_25294(cx - 1, cy + gap, cx + 1, cy + r,   ACCENT2);
        g.method_25294(cx - r,   cy - 1, cx - gap, cy + 1, ACCENT2);
        g.method_25294(cx + gap, cy - 1, cx + r,   cy + 1, ACCENT2);

        // Diagonal rays (pixel dots fading out)
        for (int i = 0; i < 5; i++) {
            int s = gap + i * 3;
            int alpha = Math.max(0x20, 0xAA - i * 0x1C);
            int col = (alpha << 24) | 0xFFBB44;
            g.method_25294(cx + s,     cy - s - 1, cx + s + 2, cy - s + 1, col);
            g.method_25294(cx - s - 2, cy - s - 1, cx - s,     cy - s + 1, col);
            g.method_25294(cx + s,     cy + s - 1, cx + s + 2, cy + s + 1, col);
            g.method_25294(cx - s - 2, cy + s - 1, cx - s,     cy + s + 1, col);
        }
    }

    private void drawStars(class_332 g) {
        // Deterministic pseudo-random star positions
        int[] seeds = {17, 31, 47, 59, 71, 89, 103, 127, 149, 163,
                       179, 197, 211, 233, 251, 269, 283, 307, 331, 349};
        for (int i = 0; i < seeds.length; i++) {
            int sx = (seeds[i] * 73 + i * 137) % Math.max(1, field_22789);
            int sy = (seeds[i] * 41 + i * 59)  % Math.max(1, field_22790 / 2);
            int brightness = 0x44 + (i % 3) * 0x22;
            int col = (brightness << 24) | 0xCCDDFF;
            g.method_25294(sx, sy, sx + 1, sy + 1, col);
        }
    }

    @Override
    public boolean method_25422() { return false; }

    @Override
    public boolean method_25421() { return false; }
}
