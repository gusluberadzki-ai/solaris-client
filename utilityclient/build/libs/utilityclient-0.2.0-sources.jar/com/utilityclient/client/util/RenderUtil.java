package com.utilityclient.client.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class RenderUtil {
    private RenderUtil() {
    }

    public static void panel(class_332 graphics, int x, int y, int width, int height) {
        graphics.method_25294(x, y, x + width, y + height, 0xAA1F2937);
        graphics.method_25294(x, y, x + width, y + 1, 0xFF3B82F6);
        graphics.method_25294(x, y, x + 1, y + height, 0x663B82F6);
    }

    public static void outlinedBox(class_332 graphics, int x, int y, int width, int height, int color) {
        graphics.method_73198(x, y, width, height, color);
    }

    public static void text(class_332 graphics, String text, int x, int y, int color) {
        class_327 font = class_310.method_1551().field_1772;
        graphics.method_51433(font, text, x, y, color, true);
    }

    public static void centered(class_332 graphics, class_2561 text, int centerX, int y, int color) {
        class_327 font = class_310.method_1551().field_1772;
        graphics.method_27534(font, text, centerX, y, color);
    }

    public static int durabilityColor(double percent) {
        if (percent > 0.6) {
            return 0xFF10B981;
        }
        if (percent > 0.3) {
            return 0xFFFBBF24;
        }
        return 0xFFEF4444;
    }
}
