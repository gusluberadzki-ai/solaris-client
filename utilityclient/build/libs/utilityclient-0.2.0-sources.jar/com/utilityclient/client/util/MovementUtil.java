package com.utilityclient.client.util;

import net.minecraft.class_1297;
import net.minecraft.class_746;

public final class MovementUtil {
    private MovementUtil() {
    }

    public static double horizontalSpeed(class_1297 entity) {
        double dx = entity.method_23317() - entity.field_6038;
        double dz = entity.method_23321() - entity.field_5989;
        return Math.sqrt(dx * dx + dz * dz) * 20.0D;
    }

    public static double verticalSpeed(class_1297 entity) {
        return (entity.method_23318() - entity.field_5971) * 20.0D;
    }

    public static MovementMode mode(class_746 player) {
        if (player.method_5854() != null) {
            String id = player.method_5854().method_5864().toString().toLowerCase();
            if (id.contains("zombie_nautilus")) {
                return MovementMode.ZOMBIE_NAUTILUS;
            }
            if (id.contains("nautilus")) {
                return MovementMode.NAUTILUS;
            }
            if (id.contains("camel_husk")) {
                return MovementMode.CAMEL_HUSK;
            }
            if (id.contains("camel")) {
                return MovementMode.CAMEL;
            }
            if (id.contains("zombie_horse")) {
                return MovementMode.ZOMBIE_HORSE;
            }
            return MovementMode.HORSE;
        }
        if (player.method_6128()) {
            return MovementMode.ELYTRA;
        }
        if (player.method_5681()) {
            return MovementMode.SWIMMING;
        }
        if (player.method_5624()) {
            return MovementMode.SPRINTING;
        }
        return MovementMode.WALKING;
    }
}
