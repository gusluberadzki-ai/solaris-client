package com.utilityclient.client.mixin;

import net.minecraft.class_1702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1702.class)
public interface FoodDataAccessor {
    @Accessor("exhaustionLevel")
    float utilityclient$getExhaustionLevel();
}
