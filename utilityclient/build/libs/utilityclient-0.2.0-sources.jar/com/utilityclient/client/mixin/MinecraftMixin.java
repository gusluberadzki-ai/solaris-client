package com.utilityclient.client.mixin;

import com.utilityclient.client.gui.SolarisScreen;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftMixin {

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void solaris$redirectTitle(class_437 screen, CallbackInfo ci) {
        if (screen instanceof class_442) {
            ((class_310) (Object) this).method_1507(new SolarisScreen());
            ci.cancel();
        }
    }
}
