package com.utilityclient.client;

import com.utilityclient.UtilityClient;
import com.utilityclient.client.config.ConfigManager;
import com.utilityclient.client.event.ClientEventBus;
import com.utilityclient.client.gui.ClickGuiScreen;
import com.utilityclient.client.gui.HudEditorScreen;
import com.utilityclient.client.gui.WorldMapScreen;
import com.utilityclient.client.manager.HudManager;
import com.utilityclient.client.manager.ModuleManager;
import com.utilityclient.client.util.TpsTracker;
import com.utilityclient.client.waypoint.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class UtilityClientClient implements ClientModInitializer {
    public static ModuleManager moduleManager;
    public static ConfigManager configManager;
    public static HudManager hudManager;
    public static WaypointManager waypointManager;

    public static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
        class_2960.method_60655(UtilityClient.MOD_ID, "controls")
    );

    // Right Ctrl opens the Click GUI per spec; Right Shift opens HUD Editor.
    public static final class_304 CLICK_GUI_KEY = new class_304(
        "key.utilityclient.click_gui",
        class_3675.class_307.field_1668,
        GLFW.GLFW_KEY_RIGHT_CONTROL,
        KEY_CATEGORY
    );

    public static final class_304 HUD_EDITOR_KEY = new class_304(
        "key.utilityclient.hud_editor",
        class_3675.class_307.field_1668,
        GLFW.GLFW_KEY_RIGHT_SHIFT,
        KEY_CATEGORY
    );

    public static final class_304 WORLD_MAP_KEY = new class_304(
        "key.utilityclient.world_map",
        class_3675.class_307.field_1668,
        GLFW.GLFW_KEY_M,
        KEY_CATEGORY
    );

    public static final class_304 ZOOM_KEY = new class_304(
        "key.utilityclient.zoom",
        class_3675.class_307.field_1668,
        GLFW.GLFW_KEY_V,
        KEY_CATEGORY
    );

    @Override
    public void onInitializeClient() {
        KeyBindingHelper.registerKeyBinding(CLICK_GUI_KEY);
        KeyBindingHelper.registerKeyBinding(HUD_EDITOR_KEY);
        KeyBindingHelper.registerKeyBinding(WORLD_MAP_KEY);
        KeyBindingHelper.registerKeyBinding(ZOOM_KEY);

        waypointManager = new WaypointManager();
        hudManager = new HudManager();
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();

        moduleManager.registerDefaults();
        configManager.loadAll();
        TpsTracker.register();
        ClientEventBus.register();

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> configManager.saveAll());
        UtilityClient.LOGGER.info("Utility Client client initialized.");
    }

    public static void handleGlobalKeys() {
        var client = net.minecraft.class_310.method_1551();

        while (CLICK_GUI_KEY.method_1436()) {
            client.method_1507(new ClickGuiScreen());
        }

        while (HUD_EDITOR_KEY.method_1436()) {
            client.method_1507(new HudEditorScreen());
        }

        while (WORLD_MAP_KEY.method_1436()) {
            client.method_1507(new WorldMapScreen());
        }
    }
}
